import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, Branch, Product, CartItem } from '../types';
import { mockUsers, mockBranches, mockProducts, mockCustomers, mockTransactions, mockGRNs, mockSuppliers, mockDiscounts, mockNotifications, mockCategories } from '../utils/mockData';

interface AppContextType {
  currentUser: User | null;
  currentBranch: Branch | null;
  isOnline: boolean;
  users: User[];
  branches: Branch[];
  products: Product[];
  cart: CartItem[];
  notifications: typeof mockNotifications;
  customers: typeof mockCustomers;
  transactions: typeof mockTransactions;
  suppliers: typeof mockSuppliers;
  grns: typeof mockGRNs;
  discounts: typeof mockDiscounts;
  categories: typeof mockCategories;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  setCurrentBranch: (branch: Branch) => void;
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => { subtotal: number; tax: number; total: number };
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentBranch, setCurrentBranch] = useState<Branch | null>(null);
  const [isOnline] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);

  const login = (email: string, _password: string): boolean => {
    const user = mockUsers.find(u => u.email === email);
    if (user) {
      setCurrentUser(user);
      if (user.branchId) {
        const branch = mockBranches.find(b => b.id === user.branchId);
        if (branch) setCurrentBranch(branch);
      } else {
        setCurrentBranch(mockBranches[0]);
      }
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentBranch(null);
    setCart([]);
  };

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === product.id);
      if (existing) {
        return prev.map(item =>
          item.productId === product.id
            ? { ...item, quantity: item.quantity + quantity, total: (item.quantity + quantity) * item.unitPrice }
            : item
        );
      }
      return [...prev, {
        id: `cart-${Date.now()}`,
        productId: product.id,
        product,
        quantity,
        unitPrice: product.sellingPrice,
        discount: 0,
        total: product.sellingPrice * quantity
      }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item =>
      item.productId === productId
        ? { ...item, quantity, total: quantity * item.unitPrice }
        : item
    ));
  };

  const clearCart = () => setCart([]);

  const getCartTotal = () => {
    const subtotal = cart.reduce((sum, item) => sum + item.total, 0);
    const tax = subtotal * 0.10;
    return { subtotal, tax, total: subtotal + tax };
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      currentBranch,
      isOnline,
      users: mockUsers,
      branches: mockBranches,
      products: mockProducts,
      cart,
      notifications: mockNotifications,
      customers: mockCustomers,
      transactions: mockTransactions,
      suppliers: mockSuppliers,
      grns: mockGRNs,
      discounts: mockDiscounts,
      categories: mockCategories,
      login,
      logout,
      setCurrentBranch,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      getCartTotal
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};