export type UserRole = 'super_admin' | 'branch_manager' | 'cashier';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  branchId?: string;
  avatar?: string;
  permissions: string[];
  createdAt: Date;
  lastLogin?: Date;
  status: 'active' | 'inactive' | 'suspended';
}

export interface Branch {
  id: string;
  name: string;
  code: string;
  address: string;
  phone: string;
  email: string;
  managerId: string;
  status: 'active' | 'inactive';
  terminals: Terminal[];
  createdAt: Date;
}

export interface Terminal {
  id: string;
  name: string;
  branchId: string;
  type: 'main' | 'pos';
  status: 'online' | 'offline' | 'maintenance';
  lastSync?: Date;
}

export interface Category {
  id: string;
  name: string;
  parentId?: string;
}

export interface Product {
  id: string;
  sku: string;
  barcode: string;
  name: string;
  description: string;
  categoryId: string;
  unit: string;
  costPrice: number;
  sellingPrice: number;
  branchPrices: Record<string, number>;
  stock: Record<string, number>;
  reorderLevel: number;
  batchTracking: boolean;
  batches: ProductBatch[];
  status: 'active' | 'inactive' | 'discontinued';
  createdAt: Date;
  updatedAt: Date;
}

export interface ProductBatch {
  id: string;
  productId: string;
  batchNumber: string;
  quantity: number;
  expiryDate?: Date;
  receivedDate: Date;
  branchId: string;
}

export interface Supplier {
  id: string;
  name: string;
  code: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  products: string[];
  status: 'active' | 'inactive';
}

export interface GRN {
  id: string;
  grnNumber: string;
  supplierId: string;
  supplier?: Supplier;
  branchId: string;
  items: GRNItem[];
  totalAmount: number;
  status: 'pending' | 'approved' | 'received' | 'cancelled';
  createdBy: string;
  createdAt: Date;
}

export interface GRNItem {
  id: string;
  productId: string;
  quantity: number;
  unitCost: number;
  batchNumber: string;
  total: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  idType?: 'national_id' | 'passport' | 'driver_license';
  idNumber?: string;
  creditLimit: number;
  currentBalance: number;
  status: 'active' | 'inactive' | 'blocked';
  createdAt: Date;
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  quantity: number;
  unitPrice: number;
  discount: number;
  total: number;
}

export interface Transaction {
  id: string;
  transactionNumber: string;
  type: 'sale' | 'return' | 'credit_sale' | 'payment_received';
  branchId: string;
  terminalId: string;
  customerId?: string;
  items: TransactionItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paymentMethod: PaymentInfo[];
  status: 'completed' | 'pending' | 'cancelled' | 'refunded';
  cashierId: string;
  createdAt: Date;
}

export interface TransactionItem {
  id: string;
  productId: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  total: number;
}

export interface PaymentInfo {
  type: 'cash' | 'card' | 'digital_wallet' | 'credit';
  amount: number;
  reference?: string;
}

export interface Discount {
  id: string;
  code: string;
  name: string;
  type: 'percentage' | 'fixed';
  value: number;
  applicableTo: 'all' | 'products' | 'categories';
  minPurchase?: number;
  maxDiscount?: number;
  startDate: Date;
  endDate: Date;
  currentUsage: number;
  status: 'active' | 'inactive' | 'expired';
}

export interface Notification {
  id: string;
  type: 'low_stock' | 'sales_alert' | 'system' | 'credit_due';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high';
  read: boolean;
  createdAt: Date;
}