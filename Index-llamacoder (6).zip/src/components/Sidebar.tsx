import React from 'react';
import { Home, Users, Package, ShoppingCart, FileText, BarChart3, Settings, Building2, LogOut, ChevronLeft } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ROLE_LABELS } from '../utils/constants';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, collapsed, setCollapsed }) => {
  const { currentUser, logout } = useApp();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home, roles: ['super_admin', 'branch_manager', 'cashier'] },
    { id: 'pos', label: 'POS Terminal', icon: ShoppingCart, roles: ['super_admin', 'branch_manager', 'cashier'] },
    { id: 'products', label: 'Products', icon: Package, roles: ['super_admin', 'branch_manager'] },
    { id: 'inventory', label: 'Inventory', icon: Package, roles: ['super_admin', 'branch_manager'] },
    { id: 'customers', label: 'Customers', icon: Users, roles: ['super_admin', 'branch_manager', 'cashier'] },
    { id: 'grn', label: 'GRN', icon: FileText, roles: ['super_admin', 'branch_manager'] },
    { id: 'reports', label: 'Reports', icon: BarChart3, roles: ['super_admin', 'branch_manager'] },
    { id: 'branches', label: 'Branches', icon: Building2, roles: ['super_admin'] },
    { id: 'users', label: 'Users', icon: Users, roles: ['super_admin'] },
    { id: 'settings', label: 'Settings', icon: Settings, roles: ['super_admin'] },
  ];

  const filteredMenu = menuItems.filter(item => 
    currentUser && item.roles.includes(currentUser.role)
  );

  return (
    <div className={`${collapsed ? 'w-20' : 'w-64'} bg-slate-900 text-white flex flex-col transition-all duration-300`}>
      <div className="p-4 border-b border-slate-700 flex items-center justify-between">
        {!collapsed && (
          <div>
            <h1 className="text-xl font-bold text-white">TradeCenter</h1>
            <p className="text-xs text-slate-400">Enterprise Management</p>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 hover:bg-slate-700 rounded-lg"
        >
          <ChevronLeft className={`w-5 h-5 transition-transform ${collapsed ? 'rotate-180' : ''}`} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto py-4">
        <nav className="px-2 space-y-1">
          {filteredMenu.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                activeTab === item.id
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </button>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-slate-700">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center font-bold">
            {currentUser?.avatar || 'U'}
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{currentUser?.name}</p>
              <p className="text-xs text-slate-400">{currentUser?.role && ROLE_LABELS[currentUser.role]}</p>
            </div>
          )}
        </div>
        {!collapsed && (
          <button
            onClick={logout}
            className="w-full flex items-center gap-2 px-3 py-2 text-slate-300 hover:bg-slate-700 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default Sidebar;