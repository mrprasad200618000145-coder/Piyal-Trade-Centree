import React from 'react';
import { Bell, Wifi, WifiOff, Building2, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface HeaderProps {
  title: string;
}

const Header: React.FC<HeaderProps> = ({ title }) => {
  const { currentBranch, isOnline, notifications, currentUser } = useApp();
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{title}</h1>
          <div className="flex items-center gap-2 mt-1 text-sm text-slate-500">
            <Building2 className="w-4 h-4" />
            <span>{currentBranch?.name || 'All Branches'}</span>
            <span className="mx-2">•</span>
            {isOnline ? (
              <span className="flex items-center gap-1 text-green-600">
                <Wifi className="w-4 h-4" /> Online
              </span>
            ) : (
              <span className="flex items-center gap-1 text-red-600">
                <WifiOff className="w-4 h-4" /> Offline
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search..."
              className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <button className="relative p-2 hover:bg-gray-100 rounded-lg">
            <Bell className="w-5 h-5 text-gray-600" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-lg">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
              {currentUser?.avatar || 'U'}
            </div>
            <div className="text-sm hidden md:block">
              <p className="font-medium text-slate-800">{currentUser?.name}</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;