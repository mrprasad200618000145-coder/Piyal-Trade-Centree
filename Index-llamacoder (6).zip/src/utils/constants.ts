export const SYSTEM_CONFIG = {
  companyName: 'TradeCenter Pro',
  version: '2.0.0',
  currency: { symbol: '$', code: 'USD' },
  tax: { rate: 0.10, name: 'VAT' },
};

export const ROLE_LABELS: Record<string, string> = {
  super_admin: 'Super Admin',
  branch_manager: 'Branch Manager',
  cashier: 'Cashier',
};

export const PAYMENT_METHODS = [
  { id: 'cash', name: 'Cash', icon: '💵' },
  { id: 'card', name: 'Card', icon: '💳' },
  { id: 'digital_wallet', name: 'Digital Wallet', icon: '📱' },
  { id: 'credit', name: 'Credit', icon: '📝' },
];