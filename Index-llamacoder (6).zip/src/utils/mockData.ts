import { User, Branch, Product, Category, Customer, Supplier, Discount, Transaction, GRN, Notification } from '../types';

export const mockUsers: User[] = [
  { id: 'usr-001', name: 'John Smith', email: 'john@tradecenter.com', role: 'super_admin', permissions: [], createdAt: new Date(), status: 'active', avatar: 'JS' },
  { id: 'usr-002', name: 'Sarah Johnson', email: 'sarah@tradecenter.com', role: 'branch_manager', branchId: 'br-001', permissions: [], createdAt: new Date(), status: 'active', avatar: 'SJ' },
  { id: 'usr-003', name: 'Mike Wilson', email: 'mike@tradecenter.com', role: 'cashier', branchId: 'br-001', permissions: [], createdAt: new Date(), status: 'active', avatar: 'MW' },
];

export const mockBranches: Branch[] = [
  { id: 'br-001', name: 'Main Branch - Downtown', code: 'HQ-001', address: '123 Main Street', phone: '+1-555-0100', email: 'main@tradecenter.com', managerId: 'usr-002', status: 'active', terminals: [{ id: 'tm-001', name: 'Terminal 1', branchId: 'br-001', type: 'main', status: 'online' }], createdAt: new Date() },
  { id: 'br-002', name: 'Branch - East Side', code: 'BR-002', address: '456 East Avenue', phone: '+1-555-0200', email: 'east@tradecenter.com', managerId: 'usr-002', status: 'active', terminals: [{ id: 'tm-002', name: 'Terminal 1', branchId: 'br-002', type: 'main', status: 'online' }], createdAt: new Date() },
  { id: 'br-003', name: 'Branch - West Mall', code: 'BR-003', address: '789 West Mall', phone: '+1-555-0300', email: 'west@tradecenter.com', managerId: 'usr-002', status: 'active', terminals: [{ id: 'tm-003', name: 'Terminal 1', branchId: 'br-003', type: 'main', status: 'online' }], createdAt: new Date() },
];

export const mockCategories: Category[] = [
  { id: 'cat-001', name: 'Electronics' },
  { id: 'cat-002', name: 'Groceries' },
  { id: 'cat-003', name: 'Beverages', parentId: 'cat-002' },
  { id: 'cat-004', name: 'Household' },
  { id: 'cat-005', name: 'Personal Care' },
];

export const mockProducts: Product[] = [
  { id: 'prod-001', sku: 'ELEC-001', barcode: '8901234567890', name: 'Wireless Bluetooth Headphones', description: 'Premium wireless headphones', categoryId: 'cat-001', unit: 'piece', costPrice: 45, sellingPrice: 79.99, branchPrices: { 'br-001': 79.99, 'br-002': 82.99, 'br-003': 79.99 }, stock: { 'br-001': 150, 'br-002': 75, 'br-003': 100 }, reorderLevel: 20, batchTracking: false, batches: [], status: 'active', createdAt: new Date(), updatedAt: new Date() },
  { id: 'prod-002', sku: 'BEV-001', barcode: '8901234567891', name: 'Premium Coffee Beans 1kg', description: 'Arabica coffee beans', categoryId: 'cat-003', unit: 'piece', costPrice: 12, sellingPrice: 24.99, branchPrices: { 'br-001': 24.99, 'br-002': 24.99, 'br-003': 26.99 }, stock: { 'br-001': 200, 'br-002': 120, 'br-003': 80 }, reorderLevel: 30, batchTracking: true, batches: [], status: 'active', createdAt: new Date(), updatedAt: new Date() },
  { id: 'prod-003', sku: 'SNACK-001', barcode: '8901234567892', name: 'Organic Dark Chocolate Bar', description: '70% cocoa dark chocolate', categoryId: 'cat-002', unit: 'piece', costPrice: 3.5, sellingPrice: 7.99, branchPrices: { 'br-001': 7.99, 'br-002': 7.99, 'br-003': 8.49 }, stock: { 'br-001': 500, 'br-002': 300, 'br-003': 250 }, reorderLevel: 50, batchTracking: true, batches: [], status: 'active', createdAt: new Date(), updatedAt: new Date() },
  { id: 'prod-004', sku: 'DAIRY-001', barcode: '8901234567893', name: 'Fresh Whole Milk 1L', description: 'Farm fresh whole milk', categoryId: 'cat-002', unit: 'piece', costPrice: 1.2, sellingPrice: 2.99, branchPrices: { 'br-001': 2.99, 'br-002': 2.99, 'br-003': 3.29 }, stock: { 'br-001': 300, 'br-002': 200, 'br-003': 150 }, reorderLevel: 100, batchTracking: true, batches: [], status: 'active', createdAt: new Date(), updatedAt: new Date() },
  { id: 'prod-005', sku: 'HH-001', barcode: '8901234567894', name: 'Eco-Friendly Dish Soap', description: 'Biodegradable dish soap', categoryId: 'cat-004', unit: 'piece', costPrice: 2, sellingPrice: 4.99, branchPrices: { 'br-001': 4.99, 'br-002': 4.99, 'br-003': 5.29 }, stock: { 'br-001': 400, 'br-002': 250, 'br-003': 180 }, reorderLevel: 60, batchTracking: false, batches: [], status: 'active', createdAt: new Date(), updatedAt: new Date() },
  { id: 'prod-006', sku: 'ELEC-002', barcode: '8901234567895', name: 'USB-C Fast Charger 65W', description: 'Universal fast charger', categoryId: 'cat-001', unit: 'piece', costPrice: 18, sellingPrice: 39.99, branchPrices: { 'br-001': 39.99, 'br-002': 42.99, 'br-003': 39.99 }, stock: { 'br-001': 80, 'br-002': 45, 'br-003': 60 }, reorderLevel: 15, batchTracking: false, batches: [], status: 'active', createdAt: new Date(), updatedAt: new Date() },
  { id: 'prod-007', sku: 'PC-001', barcode: '8901234567896', name: 'Natural Shampoo 400ml', description: 'Sulfate-free shampoo', categoryId: 'cat-005', unit: 'piece', costPrice: 5.5, sellingPrice: 12.99, branchPrices: { 'br-001': 12.99, 'br-002': 12.99, 'br-003': 13.99 }, stock: { 'br-001': 180, 'br-002': 120, 'br-003': 90 }, reorderLevel: 25, batchTracking: false, batches: [], status: 'active', createdAt: new Date(), updatedAt: new Date() },
  { id: 'prod-008', sku: 'BEV-002', barcode: '8901234567897', name: 'Sparkling Water 6-Pack', description: 'Natural sparkling water', categoryId: 'cat-003', unit: 'pack', costPrice: 4, sellingPrice: 8.99, branchPrices: { 'br-001': 8.99, 'br-002': 8.99, 'br-003': 9.49 }, stock: { 'br-001': 220, 'br-002': 150, 'br-003': 100 }, reorderLevel: 40, batchTracking: false, batches: [], status: 'active', createdAt: new Date(), updatedAt: new Date() },
];

export const mockCustomers: Customer[] = [
  { id: 'cust-001', name: 'Robert Anderson', phone: '+1-555-2001', email: 'robert@email.com', address: '123 Oak Street', idType: 'national_id', idNumber: 'ID-123456789', creditLimit: 5000, currentBalance: 1250.50, status: 'active', createdAt: new Date() },
  { id: 'cust-002', name: 'Jennifer Martinez', phone: '+1-555-2002', email: 'jennifer@email.com', address: '456 Pine Avenue', idType: 'driver_license', idNumber: 'DL-987654321', creditLimit: 3000, currentBalance: 0, status: 'active', createdAt: new Date() },
  { id: 'cust-003', name: 'Michael Thompson', phone: '+1-555-2003', email: 'michael@email.com', address: '789 Maple Road', idType: 'passport', idNumber: 'PP-456789123', creditLimit: 10000, currentBalance: 3500, status: 'active', createdAt: new Date() },
];

export const mockSuppliers: Supplier[] = [
  { id: 'sup-001', name: 'Global Electronics Ltd', code: 'GEL', contactPerson: 'David Lee', phone: '+1-555-1001', email: 'david@globalelec.com', address: '100 Tech Park', products: ['prod-001', 'prod-006'], status: 'active' },
  { id: 'sup-002', name: 'Fresh Foods Distribution', code: 'FFD', contactPerson: 'Maria Garcia', phone: '+1-555-1002', email: 'maria@freshfoods.com', address: '200 Food Street', products: ['prod-002', 'prod-004', 'prod-008'], status: 'active' },
  { id: 'sup-003', name: 'Organic Supplies Co', code: 'OSC', contactPerson: 'Tom Wilson', phone: '+1-555-1003', email: 'tom@organicsupplies.com', address: '300 Organic Way', products: ['prod-003', 'prod-005', 'prod-007'], status: 'active' },
];

export const mockDiscounts: Discount[] = [
  { id: 'disc-001', code: 'SAVE10', name: '10% Off Electronics', type: 'percentage', value: 10, applicableTo: 'categories', minPurchase: 50, startDate: new Date('2024-01-01'), endDate: new Date('2024-12-31'), currentUsage: 125, status: 'active' },
  { id: 'disc-002', code: 'FLAT5', name: '$5 Off Orders Over $30', type: 'fixed', value: 5, applicableTo: 'all', minPurchase: 30, maxDiscount: 5, startDate: new Date('2024-01-01'), endDate: new Date('2024-06-30'), currentUsage: 89, status: 'active' },
];

export const mockTransactions: Transaction[] = [
  { id: 'txn-001', transactionNumber: 'TXN-20240115-143022-001', type: 'sale', branchId: 'br-001', terminalId: 'tm-001', items: [{ id: 'item-001', productId: 'prod-001', quantity: 2, unitPrice: 79.99, discount: 0, total: 159.98 }], subtotal: 159.98, discount: 0, tax: 16, total: 175.98, paymentMethod: [{ type: 'cash', amount: 175.98 }], status: 'completed', cashierId: 'usr-003', createdAt: new Date() },
  { id: 'txn-002', transactionNumber: 'TXN-20240115-150533-002', type: 'credit_sale', branchId: 'br-001', terminalId: 'tm-001', customerId: 'cust-001', items: [{ id: 'item-002', productId: 'prod-002', quantity: 1, unitPrice: 24.99, discount: 0, total: 24.99 }], subtotal: 24.99, discount: 0, tax: 2.5, total: 27.49, paymentMethod: [{ type: 'credit', amount: 27.49 }], status: 'completed', cashierId: 'usr-003', createdAt: new Date() },
];

export const mockGRNs: GRN[] = [
  { id: 'grn-001', grnNumber: 'GRN-20240110-0001', supplierId: 'sup-001', branchId: 'br-001', items: [{ id: 'grn-item-001', productId: 'prod-001', quantity: 50, unitCost: 45, batchNumber: 'B2024001', total: 2250 }], totalAmount: 2250, status: 'received', createdBy: 'usr-001', createdAt: new Date() },
  { id: 'grn-002', grnNumber: 'GRN-20240112-0002', supplierId: 'sup-002', branchId: 'br-002', items: [{ id: 'grn-item-002', productId: 'prod-002', quantity: 100, unitCost: 12, batchNumber: 'B2024003', total: 1200 }], totalAmount: 1200, status: 'pending', createdBy: 'usr-002', createdAt: new Date() },
];

export const mockNotifications: Notification[] = [
  { id: 'notif-001', type: 'low_stock', title: 'Low Stock Alert', message: 'USB-C Fast Charger is running low', priority: 'high', read: false, createdAt: new Date() },
  { id: 'notif-002', type: 'sales_alert', title: 'Daily Target Achieved', message: 'Main Branch achieved daily sales target', priority: 'medium', read: false, createdAt: new Date() },
  { id: 'notif-003', type: 'credit_due', title: 'Credit Payment Due', message: 'Robert Anderson has outstanding balance of $1,250.50', priority: 'medium', read: false, createdAt: new Date() },
];